//
// openGLCD build information
// This headerfile is automatically generated
//

#ifndef __openGLCD_Buildinfo_h__
#define __openGLCD_Buildinfo_h__

#define GLCD_GLCDLIB_BUILD_DATESTR	"Sun Nov 23 13:33:35 CST 2014"
#define GLCD_GLCDLIB_BUILD_REVSTR	"1.0rc1"
#define GLCD_GLCDLIB_BUILD_BUILDSTR	"v1.0rc1"
#endif
