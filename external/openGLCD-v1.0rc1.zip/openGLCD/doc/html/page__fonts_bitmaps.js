var page__fonts_bitmaps =
[
    [ "Using Fonts", "page__fonts.html", null ],
    [ "Using Bitmaps", "page__bitmaps.html", null ]
];