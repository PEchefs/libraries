var searchData=
[
  ['glcd_5fdevice_5fmode',['glcd_device_mode',['../group__glcd___device__enum.html#ga157abf7f46fa0bb87bb1cd10e5b7c12d',1,'glcd_Device.h']]],
  ['gtextfmt_5ft',['gTextfmt_t',['../group__glcd__enum.html#gaa42ab7cad2413f125d864b504e2ee909',1,'gText.h']]],
  ['gtextmode',['gTextMode',['../group__glcd__enum.html#gadc961ca1c8936ce7bc7aae778a8a84e7',1,'gText.h']]],
  ['gtextprop_5ft',['gTextProp_t',['../group__glcd__enum.html#gacdd60064702e4b0cc2f353082db3f615',1,'gText.h']]]
];
