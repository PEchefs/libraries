var searchData=
[
  ['write',['write',['../classg_text.html#ada436a4b74c69ffbd4dc02b4b03d2cd3',1,'gText']]],
  ['writedata',['WriteData',['../classglcd___device.html#aa87c10753a0ea36aa0b07801d487f069',1,'glcd_Device']]]
];
