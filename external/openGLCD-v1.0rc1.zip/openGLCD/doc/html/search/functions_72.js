var searchData=
[
  ['readdata',['ReadData',['../classglcd.html#abe22f47712e6a01c65e1f5e4b1023028',1,'glcd::ReadData()'],['../classglcd___device.html#abe22f47712e6a01c65e1f5e4b1023028',1,'glcd_Device::ReadData()']]]
];
